#!/bin/sh
opendiff "$@" | cat
